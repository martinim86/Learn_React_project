import React, { Component } from 'react'

export class List extends Component {
    render() {
        return (
            <div>
                Todo list
            </div>
        )
    }
}

export default List
