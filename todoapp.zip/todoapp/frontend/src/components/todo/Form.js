import React, { Component } from 'react'

export class Form extends Component {
    render() {
        return (
            <div>
                Add todo form
            </div>
        )
    }
}

export default Form
